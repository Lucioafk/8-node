console.log("hello estou rodando via script");
console.log("Iniciando servidor");
