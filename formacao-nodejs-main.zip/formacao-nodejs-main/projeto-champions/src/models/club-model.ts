export interface ClubModel {
  id: number;
  name: string;
}
