//export default

//export default async
exports.connectToDatabase = async (dataName) => {
  console.log("se conectando ao banco :" + dataName);
};

exports.disconnectDatabase = async () => {
  // lógica
  console.log("desconectando");
};
