const devArea = {
  version: "01ab",
  production: false,
};

const client = {
  device: "web",
};

module.exports = {
  devArea,
  client,
};
