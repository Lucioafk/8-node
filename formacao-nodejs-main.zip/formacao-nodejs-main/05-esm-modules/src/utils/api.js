export const key = {
  value: "2313jklfds",
  permission: "admin",
};

export const getDataFromApi = () => {
  console.log("dados da api sendo buscados...");
};
